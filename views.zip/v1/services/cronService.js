const activityService = require("./activityService");
const cron = require("node-cron");
// cron.schedule("* * * * *", function () {
//    var activityStatus= await activityService.search({})
//     await activityService.updateQuery({})
// });
